 


var phn="966554072052";
var end_date="20-3-2023";
var end_time="12:00";
var ad_source="snap   ";
var action_url="https://script.google.com/macros/s/AKfycbw3xgejnNzUPIynKsVOg3ODU0HbNLAu1bRYoZOQJoAEZehaXkjI5O9XXqaSrEocjFlp/exec";






 